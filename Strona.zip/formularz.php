<?php
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $country = $_POST['country'];
  if (isset($_POST["submit"])) {
    if ($name && $surname && $day && $month && $year && $country) {
      echo 'Imię: ', $name;
      echo 'Nazwisko: ',$surname;
      echo 'Data urodznia: ', $day ,' ',$month,' ',$year;
      if (isset($_POST["male"]))
        echo '<li>Mężczyzna.</li>';
      else
       echo '<li>Kobieta.</li>';
       if (isset($_POST["newsletter"]))
       echo '<li>Subskrybuję newsletter e-mail z ofertami oraz informacjami na temat tytułów
       XYZ. Subskrypcję mogę anulować w dowolnym momencie..</li>';
       if (isset($_POST["statue"]))
        echo '<li>Akceptuję Warunki użytkowania, Warunki sprzedaży oraz Politykę prywatności
        firmy XYZ.</li>';
    } else {
      
      echo '<p>Pozostały puste pola</p>';
      echo '<p><a href=\"strona3.html\">Formularz</a></p>'; 
    }
  }
?>
